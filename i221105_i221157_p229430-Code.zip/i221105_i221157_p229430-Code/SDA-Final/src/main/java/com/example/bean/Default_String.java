package com.example.bean;

public class Default_String {
	String name;
	
	public Default_String() {
		
	}

	public Default_String(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
