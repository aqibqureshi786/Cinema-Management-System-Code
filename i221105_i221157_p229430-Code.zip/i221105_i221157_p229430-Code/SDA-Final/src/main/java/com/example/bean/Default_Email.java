package com.example.bean;

public class Default_Email {

	String email;

	public Default_Email(String email) {
		super();
		this.email = email;
	}
	
	public Default_Email() {

	}


	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
